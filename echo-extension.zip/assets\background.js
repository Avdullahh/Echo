var RiskLevel = /* @__PURE__ */ ((RiskLevel2) => {
  RiskLevel2["SAFE"] = "SAFE";
  RiskLevel2["WARNING"] = "WARNING";
  RiskLevel2["CRITICAL"] = "CRITICAL";
  RiskLevel2["UNKNOWN"] = "UNKNOWN";
  return RiskLevel2;
})(RiskLevel || {});
const API_ENDPOINT = "https://echo-6k19.onrender.com/api/blocklist";
const ALLOWLIST_RULE_ID_BASE = 48e4;
async function refreshBlocklist() {
  const store = await chrome.storage.local.get(["isProtectionOn"]);
  if (store.isProtectionOn === false) {
    console.log("Echo TrackerEngine: Skipping update — protection is OFF.");
    return;
  }
  try {
    const response = await fetch(API_ENDPOINT);
    if (!response.ok) throw new Error(`API Error: ${response.status}`);
    const dbRules = await response.json();
    console.log(`Echo TrackerEngine: Received ${dbRules.length} rules from backend.`);
    const metadata = {};
    const dynamicRules = dbRules.map((rule) => {
      metadata[rule.domain] = { owner: rule.owner, category: rule.category };
      return {
        id: rule.id,
        priority: 1,
        action: { type: chrome.declarativeNetRequest.RuleActionType.BLOCK },
        condition: {
          urlFilter: rule.domain,
          resourceTypes: [
            chrome.declarativeNetRequest.ResourceType.SCRIPT,
            chrome.declarativeNetRequest.ResourceType.IMAGE,
            chrome.declarativeNetRequest.ResourceType.XMLHTTPREQUEST,
            chrome.declarativeNetRequest.ResourceType.PING,
            chrome.declarativeNetRequest.ResourceType.SUB_FRAME
          ]
        }
      };
    });
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: dynamicRules.map((r) => r.id),
      addRules: dynamicRules
    });
    await chrome.storage.local.set({ trackerMetadata: metadata });
    console.log("Echo TrackerEngine: Dynamic rules active.");
  } catch (error) {
    console.warn("Echo TrackerEngine: Backend unavailable, using cached rules.", error);
  }
}
async function removeAllDynamicRules() {
  chrome.declarativeNetRequest.getDynamicRules((rules) => {
    const ids = rules.map((r) => r.id);
    chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: ids,
      addRules: []
    });
  });
}
async function enableAdBlocking() {
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: ["easylist_rules"]
  });
  console.log("Echo TrackerEngine: Ad blocking enabled.");
}
async function disableAdBlocking() {
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    disableRulesetIds: ["easylist_rules"]
  });
  console.log("Echo TrackerEngine: Ad blocking disabled.");
}
async function allowlistSite(hostname) {
  const result = await chrome.storage.local.get(["allowlistedSites"]);
  const sites = result.allowlistedSites || [];
  if (sites.includes(hostname)) return;
  sites.push(hostname);
  const ruleId = ALLOWLIST_RULE_ID_BASE + sites.indexOf(hostname);
  await chrome.declarativeNetRequest.updateDynamicRules({
    addRules: [{
      id: ruleId,
      priority: 1e3,
      action: { type: chrome.declarativeNetRequest.RuleActionType.ALLOW },
      condition: {
        initiatorDomains: [hostname],
        resourceTypes: [
          chrome.declarativeNetRequest.ResourceType.SCRIPT,
          chrome.declarativeNetRequest.ResourceType.IMAGE,
          chrome.declarativeNetRequest.ResourceType.XMLHTTPREQUEST,
          chrome.declarativeNetRequest.ResourceType.PING,
          chrome.declarativeNetRequest.ResourceType.SUB_FRAME
        ]
      }
    }],
    removeRuleIds: []
  });
  await chrome.storage.local.set({ allowlistedSites: sites });
  console.log(`Echo TrackerEngine: Allowlisted ${hostname}`);
}
async function removeAllowlistedSite(hostname) {
  const result = await chrome.storage.local.get(["allowlistedSites"]);
  const sites = result.allowlistedSites || [];
  const index = sites.indexOf(hostname);
  if (index === -1) return;
  const ruleId = ALLOWLIST_RULE_ID_BASE + index;
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [ruleId],
    addRules: []
  });
  await chrome.storage.local.set({ allowlistedSites: sites.filter((s) => s !== hostname) });
  console.log(`Echo TrackerEngine: Removed allowlist for ${hostname}`);
}
async function restoreAllowlistRules() {
  const result = await chrome.storage.local.get(["allowlistedSites"]);
  const sites = result.allowlistedSites || [];
  if (sites.length === 0) return;
  const rules = sites.map((hostname, index) => ({
    id: ALLOWLIST_RULE_ID_BASE + index,
    priority: 1e3,
    action: { type: chrome.declarativeNetRequest.RuleActionType.ALLOW },
    condition: {
      initiatorDomains: [hostname],
      resourceTypes: [
        chrome.declarativeNetRequest.ResourceType.SCRIPT,
        chrome.declarativeNetRequest.ResourceType.IMAGE,
        chrome.declarativeNetRequest.ResourceType.XMLHTTPREQUEST,
        chrome.declarativeNetRequest.ResourceType.PING,
        chrome.declarativeNetRequest.ResourceType.SUB_FRAME
      ]
    }
  }));
  await chrome.declarativeNetRequest.updateDynamicRules({
    addRules: rules,
    removeRuleIds: rules.map((r) => r.id)
  });
  console.log(`Echo TrackerEngine: Restored ${sites.length} allowlist rules.`);
}
function setBadgeCount(count) {
  chrome.action.setBadgeText({ text: count.toString() });
  chrome.action.setBadgeBackgroundColor({ color: "#4DFFBC" });
}
function setBadgeOn() {
  chrome.action.setBadgeText({ text: "ON" });
  chrome.action.setBadgeBackgroundColor({ color: "#4DFFBC" });
}
function setBadgeOff() {
  chrome.action.setBadgeText({ text: "OFF" });
  chrome.action.setBadgeBackgroundColor({ color: "#8B949E" });
}
function clearBadge() {
  chrome.action.setBadgeText({ text: "" });
}
const MAX_EVENTS = 2e3;
const recentLogs = /* @__PURE__ */ new Set();
function isDuplicate(domain) {
  if (recentLogs.has(domain)) return true;
  recentLogs.add(domain);
  setTimeout(() => recentLogs.delete(domain), 3e4);
  return false;
}
async function logTrackerEvent(event) {
  const result = await chrome.storage.local.get(["detectedTrackers", "trackersBlocked"]);
  let events = result.detectedTrackers || [];
  let count = (result.trackersBlocked || 0) + 1;
  events.unshift(event);
  if (events.length > MAX_EVENTS) events = events.slice(0, MAX_EVENTS);
  setBadgeCount(count);
  await chrome.storage.local.set({
    detectedTrackers: events,
    trackersBlocked: count
  });
}
async function clearTrackerEvents() {
  await chrome.storage.local.set({
    detectedTrackers: [],
    trackersBlocked: 0
  });
}
async function logAllowedEvent(event) {
  const result = await chrome.storage.local.get(["detectedTrackers"]);
  let events = result.detectedTrackers || [];
  events.unshift(event);
  if (events.length > MAX_EVENTS) events = events.slice(0, MAX_EVENTS);
  await chrome.storage.local.set({ detectedTrackers: events });
}
const UPDATE_ALARM = "update-blocklist";
console.log("Echo: Background Engine Starting...");
chrome.runtime.onInstalled.addListener(async () => {
  await chrome.storage.local.set({
    isProtectionOn: true,
    isAdBlockingOn: true,
    isCookieBannerBlockingOn: true
  });
  await refreshBlocklist();
  await restoreAllowlistRules();
  chrome.alarms.create(UPDATE_ALARM, { periodInMinutes: 60 });
  await enableAdBlocking();
  console.log("Echo: Initialised. Ad blocking and cookie banner blocking active.");
});
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === UPDATE_ALARM) await refreshBlocklist();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.isProtectionOn) {
    const isOn = changes.isProtectionOn.newValue;
    if (isOn) {
      console.log("Echo: Protection Resumed.");
      enableAdBlocking().then(() => {
        refreshBlocklist().then(() => restoreAllowlistRules());
      });
      setBadgeOn();
    } else {
      console.log("Echo: Protection Paused.");
      removeAllDynamicRules();
      disableAdBlocking();
      setBadgeOff();
    }
  }
  if (changes.isAdBlockingOn) {
    changes.isAdBlockingOn.newValue ? enableAdBlocking() : disableAdBlocking();
  }
  if (changes.isCookieBannerBlockingOn) {
    const isEnabled = changes.isCookieBannerBlockingOn.newValue;
    console.log(`Echo: Cookie Banner Blocking ${isEnabled ? "Enabled" : "Disabled"}.`);
  }
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "ADD_ALLOWLIST") {
    allowlistSite(message.hostname).then(() => sendResponse({ success: true })).catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }
  if (message.type === "REMOVE_ALLOWLIST") {
    removeAllowlistedSite(message.hostname).then(() => sendResponse({ success: true })).catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }
  if (message.type === "COOKIE_BANNER_DETECTED") {
    const tabId = _sender.tab?.id;
    if (!tabId) {
      sendResponse({ success: false });
      return true;
    }
    chrome.storage.local.get(["cookieBannerState"], (result) => {
      const state = result.cookieBannerState || {};
      state[tabId] = {
        hostname: message.hostname,
        analysis: message.analysis,
        detectedAt: (/* @__PURE__ */ new Date()).toISOString(),
        resolved: false
      };
      chrome.storage.local.set({ cookieBannerState: state }, () => {
        chrome.action.setBadgeText({ text: "!", tabId });
        chrome.action.setBadgeBackgroundColor({ color: "#F59E0B", tabId });
        console.log(`Echo: Cookie banner detected on ${message.hostname}`);
        sendResponse({ success: true });
      });
    });
    return true;
  }
  if (message.type === "COOKIE_EXECUTE_PREFERENCE") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const activeTabId = tabs[0]?.id;
      if (!activeTabId) {
        sendResponse({ success: false });
        return;
      }
      const { preference, hostname } = message;
      chrome.storage.local.get(["cookiePreferences"], (result) => {
        const prefs = result.cookiePreferences || {};
        prefs[hostname] = preference;
        chrome.storage.local.set({ cookiePreferences: prefs }, () => {
          console.log(`Echo: Cookie preference saved for ${hostname}: ${preference}`);
        });
      });
      chrome.action.setBadgeText({ text: "", tabId: activeTabId });
      chrome.storage.local.get(["cookieBannerState"], (result) => {
        const state = result.cookieBannerState || {};
        if (state[activeTabId]) {
          state[activeTabId].resolved = true;
          chrome.storage.local.set({ cookieBannerState: state });
        }
      });
      chrome.tabs.sendMessage(activeTabId, {
        type: "COOKIE_EXECUTE_PREFERENCE",
        preference
      }, () => {
        sendResponse({ success: true });
      });
    });
    return true;
  }
  if (message.type === "COOKIE_BANNER_RESOLVED") {
    const tabId = _sender.tab?.id;
    if (!tabId) {
      sendResponse({ success: false });
      return true;
    }
    chrome.storage.local.get(["cookieBannerState"], (result) => {
      const state = result.cookieBannerState || {};
      if (state[tabId]) {
        state[tabId].resolved = true;
        chrome.storage.local.set({ cookieBannerState: state });
      }
      chrome.action.setBadgeText({ text: "", tabId });
      sendResponse({ success: true });
    });
    return true;
  }
});
chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(async (info) => {
  const match = info.request;
  const domain = new URL(match.url).hostname;
  if (isDuplicate(domain)) return;
  const store = await chrome.storage.local.get(["trackerMetadata"]);
  const meta = store.trackerMetadata?.[domain] ?? null;
  let sourceWebsite = "Unknown";
  try {
    if (match.initiator) sourceWebsite = new URL(match.initiator).hostname;
  } catch {
    sourceWebsite = "Unknown";
  }
  const event = {
    id: Date.now(),
    domain,
    sourceWebsite,
    company: meta?.owner ?? "Unknown",
    riskLevel: RiskLevel.WARNING,
    action: "Blocked",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
  await logTrackerEvent(event);
});
chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(async (info) => {
  const match = info.request;
  const domain = new URL(match.url).hostname;
  if (isDuplicate(domain)) return;
  const store = await chrome.storage.local.get(["trackerMetadata"]);
  const meta = store.trackerMetadata?.[domain] ?? null;
  let sourceWebsite = "Unknown";
  try {
    if (match.initiator) sourceWebsite = new URL(match.initiator).hostname;
  } catch {
    sourceWebsite = "Unknown";
  }
  const isAllowlisted = info.rule.ruleId >= 48e4;
  const event = {
    id: Date.now(),
    domain,
    sourceWebsite,
    company: meta?.owner ?? "Unknown",
    riskLevel: isAllowlisted ? RiskLevel.SAFE : RiskLevel.WARNING,
    action: isAllowlisted ? "Allowed" : "Blocked",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
  await logTrackerEvent(event);
});
