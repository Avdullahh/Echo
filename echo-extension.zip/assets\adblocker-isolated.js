const COSMETIC_AD_SELECTORS = [
  // Google Ads — specific IDs only
  "ins.adsbygoogle",
  '[id*="google_ads"]',
  '[id*="div-gpt-ad"]',
  'div[id^="google_ads_"]',
  'div[id^="div-gpt-"]',
  ".adsbygoogle",
  // Common ad containers — conservative exclusions to protect site UI
  '[class*="ad-container"]:not([class*="head"]):not([class*="read"]):not([class*="thread"]):not([class*="upload"]):not([class*="download"]):not([class*="spread"])',
  '[id*="ad-container"]:not([id*="head"]):not([id*="read"]):not([id*="upload"]):not([id*="download"])',
  '[class*="advertisement"]:not([class*="manage"]):not([class*="settings"])',
  // Ad networks — named networks only
  '[class*="taboola-widget"]',
  '[class*="outbrain-widget"]',
  '[class*="revcontent-widget"]',
  '[class*="mgid-widget"]',
  '[class*="native-ad-widget"]',
  // Video ads
  '[class*="video-ad-overlay"]',
  '[class*="preroll-ad"]',
  '[class*="ima-ad-container"]',
  ".ytp-ad-module",
  ".ytp-ad-overlay-container",
  // Banner ads — specific iframe sources only
  'iframe[src*="doubleclick.net/"]',
  'iframe[src*="googlesyndication.com/"]',
  'iframe[src*="googleadservices.com/"]',
  // Standard IAB banner sizes — exact dimensions only
  'iframe[width="728"][height="90"]',
  'iframe[width="300"][height="250"]',
  'iframe[width="160"][height="600"]',
  'iframe[width="300"][height="600"]',
  'iframe[width="970"][height="250"]',
  'iframe[width="320"][height="50"]',
  // FOMO / social proof popups
  ".fomo-notification",
  '[class*="fomo-notification"]',
  '[class*="sales-pop"]',
  '[class*="recent-sales"]',
  '[class*="proof-notification"]',
  // Push notification prompts
  "#onesignal-bell-container",
  "#onesignal-slidedown-container",
  '[class*="onesignal"]',
  ".notifyjs-corner",
  // Newsletter popups
  '[class*="newsletter-popup"]',
  '[class*="subscribe-popup"]',
  '[id*="newsletter-popup"]'
];
const COSMETIC_DIMMED_SELECTORS = [
  ".sponsored-post",
  ".promoted-post"
];
const WRAPPER_SELECTORS = [
  '[class*="ad-wrapper"]',
  '[class*="ad-slot"]',
  '[class*="ad-unit"]',
  '[class*="ad-zone"]',
  '[class*="ad-space"]',
  '[class*="ad-placeholder"]',
  '[id*="ad-wrapper"]',
  '[id*="ad-slot"]',
  '[id*="ad-unit"]',
  '[class*="sidebar-ad"]',
  '[class*="banner-wrapper"]',
  '[class*="sponsored-wrapper"]'
];
const SAFE_TAGS = /* @__PURE__ */ new Set([
  "body",
  "main",
  "article",
  "section",
  "nav",
  "header",
  "footer",
  "html",
  "aside",
  "form"
]);
let isEnabled = false;
let domainRulesCache = null;
let layoutObserver = null;
let collapseScheduled = false;
function buildCosmeticStylesheet() {
  const hideRules = COSMETIC_AD_SELECTORS.map((sel) => {
    try {
      document.querySelector(sel);
      return `:root ${sel}`;
    } catch {
      return null;
    }
  }).filter(Boolean).join(",\n");
  const dimRules = COSMETIC_DIMMED_SELECTORS.map((sel) => `:root ${sel}`).join(",\n");
  return `${hideRules} {
  display: none !important;
}

${dimRules} {
  opacity: 0.3 !important;
}`;
}
function injectStyles() {
  document.getElementById("echo-adblock-styles")?.remove();
  const style = document.createElement("style");
  style.id = "echo-adblock-styles";
  style.textContent = buildCosmeticStylesheet();
  (document.head || document.documentElement)?.appendChild(style);
}
function removeStyles() {
  ["echo-adblock-styles", "echo-cosmetic-generic", "echo-cosmetic-domain"].forEach((id) => {
    document.getElementById(id)?.remove();
  });
}
async function loadGeneratedCSS() {
  if (document.getElementById("echo-cosmetic-generic")) return;
  try {
    const response = await fetch(chrome.runtime.getURL("rules/cosmetic-generic.css"));
    if (!response.ok) return;
    const css = await response.text();
    const style = document.createElement("style");
    style.id = "echo-cosmetic-generic";
    style.textContent = css;
    (document.head || document.documentElement)?.appendChild(style);
  } catch {
  }
}
async function applyDomainRules() {
  if (document.getElementById("echo-cosmetic-domain")) return;
  try {
    if (!domainRulesCache) {
      const response = await fetch(chrome.runtime.getURL("rules/cosmetic-domains.json"));
      if (!response.ok) return;
      domainRulesCache = await response.json();
    }
    const hostname = window.location.hostname.toLowerCase();
    const selectors = [];
    const parts = hostname.split(".");
    for (let i = 0; i < parts.length - 1; i++) {
      const domain = parts.slice(i).join(".");
      if (domainRulesCache[domain]) selectors.push(...domainRulesCache[domain]);
    }
    if (selectors.length === 0) return;
    const css = [...new Set(selectors)].join(",\n") + " {\n  display: none !important;\n}";
    const style = document.createElement("style");
    style.id = "echo-cosmetic-domain";
    style.textContent = css;
    (document.head || document.documentElement)?.appendChild(style);
  } catch {
  }
}
const SHADOW_AD_SELECTORS = [
  "ins.adsbygoogle",
  '[id*="google_ads"]',
  '[class*="taboola-widget"]',
  '[class*="outbrain-widget"]'
];
function hideAdsInShadowDOM() {
  if (!isEnabled) return;
  document.querySelectorAll("*").forEach((node) => {
    if (node.shadowRoot && !node.shadowRoot.querySelector("#echo-shadow-styles")) {
      const style = document.createElement("style");
      style.id = "echo-shadow-styles";
      style.textContent = buildCosmeticStylesheet();
      node.shadowRoot.appendChild(style);
    }
  });
}
function isVisuallyEmpty(el) {
  if (el.children.length === 0) {
    return (el.textContent?.trim() || "").length === 0;
  }
  return Array.from(el.children).every((child) => {
    const style = window.getComputedStyle(child);
    return style.display === "none" || style.visibility === "hidden" || child.offsetHeight === 0;
  });
}
function collapseEmptyContainers() {
  WRAPPER_SELECTORS.forEach((selector) => {
    try {
      document.querySelectorAll(selector).forEach((wrapper) => {
        if (isVisuallyEmpty(wrapper)) {
          wrapper.style.setProperty("display", "none", "important");
        }
      });
    } catch {
    }
  });
  COSMETIC_AD_SELECTORS.forEach((selector) => {
    try {
      document.querySelectorAll(selector).forEach((adEl) => {
        const parent = adEl.parentElement;
        if (!parent || SAFE_TAGS.has(parent.tagName.toLowerCase())) return;
        if (isVisuallyEmpty(parent)) {
          parent.style.setProperty("display", "none", "important");
          const grandparent = parent.parentElement;
          if (grandparent && !SAFE_TAGS.has(grandparent.tagName.toLowerCase()) && isVisuallyEmpty(grandparent)) {
            grandparent.style.setProperty("display", "none", "important");
          }
        }
      });
    } catch {
    }
  });
}
function scheduleCollapse() {
  if (collapseScheduled) return;
  collapseScheduled = true;
  requestAnimationFrame(() => {
    collapseEmptyContainers();
    collapseScheduled = false;
  });
}
function setupLayoutObserver() {
  if (layoutObserver) return;
  layoutObserver = new MutationObserver((mutations) => {
    const hasStructuralChange = mutations.some(
      (m) => m.type === "childList" && (m.addedNodes.length > 0 || m.removedNodes.length > 0)
    );
    if (hasStructuralChange) scheduleCollapse();
  });
  const attach = () => {
    layoutObserver.observe(document.body, { childList: true, subtree: true });
  };
  if (document.body) {
    attach();
  } else {
    document.addEventListener("DOMContentLoaded", attach);
  }
}
function teardownLayoutObserver() {
  if (layoutObserver) {
    layoutObserver.disconnect();
    layoutObserver = null;
  }
}
function signalMainWorld(enabled) {
  window.postMessage({
    type: enabled ? "ECHO_ENABLE_BLOCKING" : "ECHO_DISABLE_BLOCKING"
  }, "*");
}
function enableBlocking() {
  isEnabled = true;
  injectStyles();
  loadGeneratedCSS().catch(() => {
  });
  applyDomainRules().catch(() => {
  });
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      collapseEmptyContainers();
      hideAdsInShadowDOM();
    });
  } else {
    collapseEmptyContainers();
    hideAdsInShadowDOM();
  }
  setupLayoutObserver();
  setInterval(() => {
    if (isEnabled) {
      collapseEmptyContainers();
      hideAdsInShadowDOM();
    }
  }, 3e3);
  signalMainWorld(true);
  console.log("[Echo AdBlock] Blocking enabled with seamless layout recovery");
}
function disableBlocking() {
  isEnabled = false;
  removeStyles();
  teardownLayoutObserver();
  document.querySelectorAll("#echo-shadow-styles").forEach((el) => el.remove());
  signalMainWorld(false);
  console.log("[Echo AdBlock] Blocking disabled");
}
function init() {
  chrome.storage.local.get(
    ["isProtectionOn", "isAdBlockingOn", "allowlistedSites"],
    (result) => {
      const protectionOn = result.isProtectionOn !== false;
      const adBlockingOn = result.isAdBlockingOn !== false;
      const allowlistedSites = result.allowlistedSites || [];
      const currentHost = window.location.hostname;
      const isSiteAllowlisted = allowlistedSites.some(
        (site) => currentHost === site || currentHost.endsWith("." + site)
      );
      if (protectionOn && adBlockingOn && !isSiteAllowlisted) {
        enableBlocking();
        if (document.readyState === "loading") {
          document.addEventListener("DOMContentLoaded", hideAdsInShadowDOM);
        }
      } else {
        const reason = !protectionOn ? "protection off" : !adBlockingOn ? "ad blocking off" : "site is allowlisted";
        console.log(`[Echo AdBlock] Disabled on init — ${reason}`);
        signalMainWorld(false);
      }
    }
  );
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (!changes.isProtectionOn && !changes.isAdBlockingOn && !changes.allowlistedSites) return;
    chrome.storage.local.get(
      ["isProtectionOn", "isAdBlockingOn", "allowlistedSites"],
      (result) => {
        const protectionOn = result.isProtectionOn !== false;
        const adBlockingOn = result.isAdBlockingOn !== false;
        const allowlistedSites = result.allowlistedSites || [];
        const currentHost = window.location.hostname;
        const isSiteAllowlisted = allowlistedSites.some(
          (site) => currentHost === site || currentHost.endsWith("." + site)
        );
        const shouldBlock = protectionOn && adBlockingOn && !isSiteAllowlisted;
        if (shouldBlock) {
          enableBlocking();
        } else {
          disableBlocking();
        }
      }
    );
  });
}
init();
