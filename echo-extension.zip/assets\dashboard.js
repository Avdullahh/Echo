/* empty css      */
import { b as buildFullProfile } from "./profileAnalyzer.js";
function formatCategory(raw) {
  return raw.replace(/([A-Z])/g, " $1").replace(/^./, (c) => c.toUpperCase()).trim();
}
function friendlyCompanyName(domain) {
  const knownMap = {
    // Google ecosystem
    "google": "Google",
    "doubleclick": "Google",
    "googlesyndication": "Google",
    "googletagmanager": "Google",
    "googletagservices": "Google",
    "googleadservices": "Google",
    "googlevideo": "Google",
    "gstatic": "Google",
    "googleapis": "Google",
    "googleusercontent": "Google",
    "gmail": "Google",
    "youtube": "Google",
    "ytimg": "Google",
    "ggpht": "Google",
    // Meta ecosystem
    "facebook": "Meta",
    "meta": "Meta",
    "instagram": "Meta",
    "whatsapp": "Meta",
    "threads": "Meta",
    "fbcdn": "Meta",
    "fbsbx": "Meta",
    "atdmt": "Meta",
    // Microsoft ecosystem
    "microsoft": "Microsoft",
    "bing": "Microsoft",
    "msn": "Microsoft",
    "live": "Microsoft",
    "outlook": "Microsoft",
    "hotmail": "Microsoft",
    "azure": "Microsoft",
    "msecnd": "Microsoft",
    "msocdn": "Microsoft",
    "office": "Microsoft",
    "sharepoint": "Microsoft",
    "linkedin": "Microsoft",
    "bat.bing": "Microsoft",
    "clarity": "Microsoft",
    // Amazon ecosystem
    "amazon": "Amazon",
    "amazon-adsystem": "Amazon",
    "amazonwebservices": "Amazon",
    "amazonaws": "Amazon",
    "cloudfront": "Amazon",
    "alexa": "Amazon",
    "twitch": "Amazon",
    "audible": "Amazon",
    "goodreads": "Amazon",
    // Apple
    "apple": "Apple",
    "icloud": "Apple",
    "itunes": "Apple",
    "mzstatic": "Apple",
    "aaplimg": "Apple",
    // TikTok / ByteDance
    "tiktok": "TikTok",
    "bytedance": "TikTok",
    "tiktokcdn": "TikTok",
    "musical.ly": "TikTok",
    "tik.tok": "TikTok",
    // Twitter / X
    "twitter": "X (Twitter)",
    "twimg": "X (Twitter)",
    "t.co": "X (Twitter)",
    "ads-twitter": "X (Twitter)",
    // Snapchat
    "snapchat": "Snapchat",
    "snap.com": "Snapchat",
    "sc-cdn": "Snapchat",
    // Pinterest
    "pinterest": "Pinterest",
    "pinimg": "Pinterest",
    // Reddit
    "reddit": "Reddit",
    "redd.it": "Reddit",
    "redditmedia": "Reddit",
    "redditusercontentcdn": "Reddit",
    // Adobe
    "adobe": "Adobe",
    "omtrdc": "Adobe",
    "demdex": "Adobe",
    "adobedtm": "Adobe",
    "2o7": "Adobe",
    "everesttech": "Adobe",
    "marketo": "Adobe",
    "scene7": "Adobe",
    // Advertising networks
    "criteo": "Criteo",
    "hotjar": "Hotjar",
    "taboola": "Taboola",
    "outbrain": "Outbrain",
    "pubmatic": "PubMatic",
    "openx": "OpenX",
    "quantcast": "Quantcast",
    "comscore": "Comscore",
    "nielsen": "Nielsen",
    "rubiconproject": "Magnite",
    "magnite": "Magnite",
    "casalemedia": "Index Exchange",
    "indexexchange": "Index Exchange",
    "appnexus": "Xandr",
    "xandr": "Xandr",
    "adnxs": "Xandr",
    "mediamath": "MediaMath",
    "tradedesk": "The Trade Desk",
    "adsrvr": "The Trade Desk",
    "liveramp": "LiveRamp",
    "rlcdn": "LiveRamp",
    "sharetthrough": "Sharethrough",
    "sharethrough": "Sharethrough",
    "triplelift": "TripleLift",
    "spotxchange": "SpotX",
    "spotx": "SpotX",
    "teads": "Teads",
    "yieldmo": "Yieldmo",
    "sovrn": "Sovrn",
    "contextweb": "Playwire",
    "pulsepoint": "PulsePoint",
    "undertone": "Undertone",
    "rhythmone": "RhythmOne",
    "33across": "33Across",
    "smartadserver": "Smart AdServer",
    "improvedigital": "Improve Digital",
    "emxdgt": "EMX Digital",
    "appier": "Appier",
    "adform": "Adform",
    "adroll": "AdRoll",
    "turn": "Amobee",
    "amobee": "Amobee",
    // Analytics
    "scorecardresearch": "Comscore",
    "chartbeat": "Chartbeat",
    "parsely": "Parse.ly",
    "newrelic": "New Relic",
    "segment": "Segment",
    "mixpanel": "Mixpanel",
    "amplitude": "Amplitude",
    "fullstory": "FullStory",
    "logrocket": "LogRocket",
    "mouseflow": "Mouseflow",
    "crazyegg": "Crazy Egg",
    "luckyorange": "Lucky Orange",
    "inspectlet": "Inspectlet",
    "heap": "Heap",
    "intercom": "Intercom",
    "drift": "Drift",
    "hubspot": "HubSpot",
    "pardot": "Salesforce",
    "salesforce": "Salesforce",
    "eloqua": "Oracle",
    // CDN / Infrastructure that tracks
    "cloudflare": "Cloudflare",
    "fastly": "Fastly",
    "akamai": "Akamai",
    "akamaized": "Akamai",
    "edgekey": "Akamai",
    "edgesuite": "Akamai",
    // Social login / identity
    "auth0": "Auth0",
    "okta": "Okta",
    "onelogin": "OneLogin",
    // News & media trackers
    "permutive": "Permutive",
    "onetrust": "OneTrust",
    "cookielaw": "OneTrust",
    "trustarc": "TrustArc",
    "quantserve": "Quantcast",
    // Shopping & retail
    "shopify": "Shopify",
    "shopifycdn": "Shopify",
    "ebay": "eBay",
    "etsy": "Etsy",
    "walmart": "Walmart",
    "target": "Target",
    "bestbuy": "Best Buy",
    // Entertainment & streaming
    "netflix": "Netflix",
    "nflximg": "Netflix",
    "nflxvideo": "Netflix",
    "spotify": "Spotify",
    "scdn": "Spotify",
    "disneyplus": "Disney+",
    "disney": "Disney",
    "hulu": "Hulu",
    "hbomax": "HBO Max",
    "max.com": "HBO Max",
    "peacocktv": "Peacock",
    "paramountplus": "Paramount+",
    // Gaming
    "steam": "Steam",
    "steampowered": "Steam",
    "epicgames": "Epic Games",
    "ea.com": "EA",
    "riotgames": "Riot Games",
    "blizzard": "Blizzard",
    "ubisoft": "Ubisoft",
    "rockstargames": "Rockstar Games",
    "xbox": "Xbox",
    "playstation": "PlayStation",
    "nintendo": "Nintendo",
    // Finance
    "paypal": "PayPal",
    "paypalobjects": "PayPal",
    "stripe": "Stripe",
    "braintree": "Braintree",
    "coinbase": "Coinbase",
    "binance": "Binance",
    "revolut": "Revolut",
    "monzo": "Monzo",
    // Travel
    "booking": "Booking.com",
    "airbnb": "Airbnb",
    "expedia": "Expedia",
    "tripadvisor": "TripAdvisor",
    "skyscanner": "Skyscanner",
    "kayak": "Kayak",
    // Food delivery
    "ubereats": "Uber Eats",
    "uber": "Uber",
    "deliveroo": "Deliveroo",
    "justeat": "Just Eat",
    "doordash": "DoorDash",
    // Productivity & comms
    "slack": "Slack",
    "zoom": "Zoom",
    "notion": "Notion",
    "atlassian": "Atlassian",
    "jira": "Atlassian",
    "confluence": "Atlassian",
    "dropbox": "Dropbox",
    // Developer tools
    "github": "GitHub",
    "gitlab": "GitLab",
    "stackoverflow": "Stack Overflow",
    "npmjs": "npm",
    "vercel": "Vercel",
    "netlify": "Netlify",
    "heroku": "Heroku",
    "digitalocean": "DigitalOcean"
  };
  const lower = domain.toLowerCase();
  for (const [key, name] of Object.entries(knownMap)) {
    if (lower.includes(key)) return name;
  }
  const parts = domain.replace(/^www\./, "").split(".");
  const meaningful = parts.length >= 2 ? parts[parts.length - 2] : parts[0];
  return meaningful.charAt(0).toUpperCase() + meaningful.slice(1);
}
function buildRiskSummary(riskLevel, trackingIntensity) {
  if (riskLevel === "Critical" || trackingIntensity === "Extreme") {
    return `You are heavily tracked. Advertisers have built a detailed profile of your online behaviour.`;
  }
  if (riskLevel === "High" || trackingIntensity === "Heavy") {
    return `You are significantly tracked across multiple sites. Your browsing habits are being used to target you with ads.`;
  }
  if (riskLevel === "Medium" || trackingIntensity === "Moderate") {
    return `Some tracking is happening. Advertisers have a partial picture of your interests based on your browsing.`;
  }
  return `Low tracking detected. You have a limited advertising profile at this time.`;
}
const analyzePrivacyFootprint = async (topCompanies, categories, recentActivity) => {
  if (!topCompanies || topCompanies.length === 0) {
    return [
      `**No data yet**`,
      ``,
      `Browse the web with Echo active and come back — your digital profile will appear here.`
    ].join("\n");
  }
  if (!categories || categories.length === 0) {
    return [
      `**Still building your profile**`,
      ``,
      `Keep browsing with Echo running. More data is needed to infer your profile accurately.`
    ].join("\n");
  }
  try {
    const profile = buildFullProfile(topCompanies, categories);
    const readableTrackers = profile.trackerCompanies.map(friendlyCompanyName).filter((v, i, a) => a.indexOf(v) === i).slice(0, 3);
    const readableInterests = profile.dominantCategories.map((cat) => {
      const name = cat.split("(")[0].trim();
      return formatCategory(name);
    }).slice(0, 3);
    const lines = [
      // Identity
      `**${profile.personaEmoji} ${profile.personaTitle}**`,
      ``,
      // One plain-English sentence about what this means
      buildRiskSummary(profile.riskLevel, profile.trackingIntensity),
      ``,
      // Why they are targeted — already plain English from profileAnalyzer
      profile.whyTargeted,
      ``
    ];
    if (readableInterests.length > 0) {
      lines.push(`**Advertisers think you're interested in:** ${readableInterests.join(", ")}`);
    }
    if (readableTrackers.length > 0) {
      lines.push(`**Who is tracking you:** ${readableTrackers.join(", ")}`);
    }
    const valueLabel = profile.dataValue === "Very High" ? "very valuable to advertisers" : profile.dataValue === "High" ? "valuable to advertisers" : profile.dataValue === "Medium" ? "moderately valuable to advertisers" : "not yet highly valuable to advertisers";
    lines.push(`**Your data is:** ${valueLabel}`);
    lines.push(``);
    lines.push(`*Your profile is built from your browsing history. No data leaves your device.*`);
    return lines.filter((line) => line !== void 0).join("\n");
  } catch (error) {
    console.error("Profile Analysis Error:", error);
    return `**Could not generate profile**

Something went wrong. Please try again.`;
  }
};
document.addEventListener("DOMContentLoaded", () => {
  function switchTab(tabId) {
    document.querySelectorAll(".view-section").forEach((el) => el.classList.add("hidden"));
    document.querySelectorAll(".nav-btn").forEach((btn) => {
      btn.classList.remove("bg-surface-cardHover", "text-text-primary", "shadow-sm");
      btn.classList.add("text-text-muted");
    });
    const targetSection = document.getElementById(tabId);
    if (targetSection) targetSection.classList.remove("hidden");
    const targetBtn = document.querySelector(`.nav-btn[data-target="${tabId}"]`);
    if (targetBtn) {
      targetBtn.classList.remove("text-text-muted");
      targetBtn.classList.add("bg-surface-cardHover", "text-text-primary", "shadow-sm");
    }
    if (tabId === "report") generateReport();
  }
  const handleHash = () => {
    const hash = window.location.hash.replace("#", "") || "home";
    switchTab(hash);
  };
  window.addEventListener("hashchange", handleHash);
  handleHash();
  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.target;
      history.pushState(null, null, `#${target}`);
      switchTab(target);
    });
  });
  let cachedData = [];
  function refreshData() {
    chrome.storage.local.get(["trackersBlocked", "detectedTrackers", "isProtectionOn"], (data) => {
      const count = data.trackersBlocked || 0;
      cachedData = data.detectedTrackers || [];
      const isProtectionOn = data.isProtectionOn !== void 0 ? data.isProtectionOn : true;
      const homeCount = document.getElementById("home-total-blocked");
      if (homeCount) homeCount.textContent = count.toLocaleString();
      updateSystemStatus(isProtectionOn);
      const timeLabel = document.getElementById("last-updated-time");
      if (timeLabel) timeLabel.textContent = (/* @__PURE__ */ new Date()).toLocaleTimeString();
      renderTrafficTable(cachedData);
      if (window.location.hash === "#report") {
        generateReport();
      }
      generatePersonaFromData();
    });
  }
  function updateSystemStatus(isOn) {
    const statusDot = document.getElementById("system-status-dot");
    const statusText = document.getElementById("system-status-text");
    if (statusDot && statusText) {
      if (isOn) {
        statusText.textContent = "Active";
        statusDot.className = "w-3 h-3 rounded-full bg-accent-primary animate-pulse";
      } else {
        statusText.textContent = "Paused";
        statusDot.className = "w-3 h-3 rounded-full bg-accent-critical";
      }
    }
  }
  refreshData();
  setInterval(refreshData, 5e3);
  function renderTrafficTable(list) {
    const tableBody = document.getElementById("tracker-list-table");
    const emptyState = document.getElementById("empty-state-traffic");
    if (!tableBody) return;
    if (list.length === 0) {
      tableBody.innerHTML = "";
      if (emptyState) emptyState.classList.remove("hidden");
      return;
    }
    if (emptyState) emptyState.classList.add("hidden");
    const grouped = list.reduce((acc, t) => {
      const key = t.company && t.company !== "Unknown" ? t.company : t.domain;
      if (!acc[key]) {
        acc[key] = { ...t, count: 0, lastSeen: t.timestamp };
      }
      acc[key].count++;
      if (new Date(t.timestamp) > new Date(acc[key].lastSeen)) {
        acc[key].lastSeen = t.timestamp;
      }
      return acc;
    }, {});
    const sorted = Object.values(grouped).sort((a, b) => new Date(b.lastSeen) - new Date(a.lastSeen));
    tableBody.innerHTML = sorted.map((t) => {
      const displayOwner = t.company && t.company !== "Unknown" ? t.company : t.domain;
      const actionBadge = t.action === "Allowed" ? `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">Bypassed</span>` : `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-accent-critical/10 text-accent-critical border border-accent-critical/20">Blocked</span>`;
      return `
            <tr class="hover:bg-surface-cardHover/50 transition-colors group">
                <td class="px-6 py-4">
                    <div class="flex items-center gap-3">
                        <div class="w-8 h-8 rounded bg-surface-inset flex items-center justify-center text-xs font-bold text-text-muted border border-border-subtle group-hover:border-accent-primary/50 group-hover:text-accent-primary transition-colors">
                            ${t.domain.charAt(0).toUpperCase()}
                        </div>
                        <div>
                            <div class="text-sm font-medium text-text-primary">${displayOwner}</div>
                            <div class="text-xs text-text-muted flex items-center gap-1.5">
                                ${actionBadge}
                                <span>${t.count} request${t.count !== 1 ? "s" : ""}</span>
                            </div>
                        </div>
                    </div>
                </td>
                <td class="px-6 py-4">
                    <span class="px-2 py-1 rounded text-[10px] font-medium tracking-wide bg-surface-inset text-text-secondary border border-border-subtle">
                        ${t.sourceWebsite && t.sourceWebsite !== "Unknown" ? t.sourceWebsite : "Direct request"}
                    </span>
                </td>
                <td class="px-6 py-4 text-right text-xs text-text-muted tabular-nums">
                    ${new Date(t.lastSeen).toLocaleTimeString()}
                </td>
            </tr>
            `;
    }).join("");
  }
  function generateReport() {
    if (!cachedData || cachedData.length === 0) return;
    const companyMap = {};
    cachedData.forEach(function(t) {
      const name = t.company && t.company !== "Unknown" ? t.company : t.domain;
      if (name) companyMap[name] = (companyMap[name] || 0) + 1;
    });
    const topCompanies = Object.entries(companyMap).sort(function(a, b) {
      return b[1] - a[1];
    }).slice(0, 4);
    const companyContainer = document.getElementById("top-companies-chart");
    if (companyContainer && topCompanies.length > 0) {
      const maxVal = topCompanies[0][1];
      companyContainer.innerHTML = topCompanies.map(function(entry) {
        const name = entry[0];
        const count = entry[1];
        const percent = count / maxVal * 100;
        return `
                <div class="mb-4">
                    <div class="flex justify-between text-xs font-medium mb-1">
                        <span class="text-text-primary">${name}</span>
                        <span class="text-text-muted">${count}</span>
                    </div>
                    <div class="w-full h-2 bg-surface-inset rounded-full overflow-hidden">
                        <div class="h-full bg-accent-primary rounded-full shadow-[0_0_10px_rgba(77,255,188,0.4)]" style="width: ${percent}%"></div>
                    </div>
                </div>`;
      }).join("");
    }
    const siteMap = {};
    cachedData.forEach(function(t) {
      const site = t.sourceWebsite;
      if (site && site !== "Unknown") {
        siteMap[site] = (siteMap[site] || 0) + 1;
      }
    });
    const topWebsites = Object.entries(siteMap).sort(function(a, b) {
      return b[1] - a[1];
    }).slice(0, 4);
    const catContainer = document.getElementById("categories-list");
    if (catContainer) {
      catContainer.innerHTML = topWebsites.map(function(entry) {
        return `
                <div class="flex items-center justify-between p-3 rounded-lg border border-border-subtle bg-surface-inset/20">
                    <span class="text-sm font-medium text-text-secondary">${entry[0]}</span>
                    <span class="text-xs font-bold text-text-primary">${entry[1]}</span>
                </div>`;
      }).join("");
    }
  }
  const aiBtn = document.getElementById("ai-generate-btn");
  const aiContainer = document.getElementById("ai-result-container");
  const aiTitle = document.getElementById("ai-persona-title");
  const aiDesc = document.getElementById("ai-persona-desc");
  if (aiContainer) aiContainer.classList.remove("hidden");
  if (aiTitle) aiTitle.textContent = "Your Profile Awaits";
  if (aiDesc) aiDesc.textContent = 'Press "Generate Persona" to see how advertising algorithms currently classify you based on your browsing data.';
  if (aiBtn) {
    aiBtn.addEventListener("click", async () => {
      aiBtn.disabled = true;
      aiBtn.textContent = "Analyzing...";
      aiTitle.textContent = "Processing...";
      aiDesc.textContent = "Aggregating tracker data to infer profile...";
      try {
        const companyMap = {};
        cachedData.forEach(function(t) {
          const name = t.company && t.company !== "Unknown" ? t.company : t.domain;
          if (name) companyMap[name] = (companyMap[name] || 0) + 1;
        });
        const allCompanies = Object.entries(companyMap).sort(function(a, b) {
          return b[1] - a[1];
        }).map(function(entry) {
          return { name: entry[0], count: entry[1] };
        });
        const siteMap = {};
        const totalEvents = cachedData.length;
        cachedData.forEach(function(t) {
          const site = t.sourceWebsite;
          if (site && site !== "Unknown") {
            siteMap[site] = (siteMap[site] || 0) + 1;
          }
        });
        const allSites = Object.entries(siteMap).sort(function(a, b) {
          return b[1] - a[1];
        }).map(function(entry) {
          return { label: entry[0], percent: Math.round(entry[1] / totalEvents * 100) };
        });
        const resultText = await analyzePrivacyFootprint(allCompanies, allSites, []);
        aiTitle.textContent = "Your Digital Profile";
        aiDesc.innerHTML = resultText.replace(/\n/g, "<br>").replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
        aiBtn.textContent = "Regenerate";
        aiBtn.disabled = false;
      } catch (err) {
        console.error(err);
        aiTitle.textContent = "Analysis Failed";
        aiDesc.textContent = err.message || "Unknown error.";
        aiBtn.disabled = false;
        aiBtn.textContent = "Retry";
      }
    });
  }
  const adBlockingToggle = document.getElementById("ad-blocking-toggle");
  if (adBlockingToggle) {
    chrome.storage.local.get(["isAdBlockingOn"], (data) => {
      adBlockingToggle.checked = data.isAdBlockingOn !== false;
    });
    adBlockingToggle.addEventListener("change", (e) => {
      const isEnabled = e.target.checked;
      chrome.storage.local.set({ isAdBlockingOn: isEnabled }, () => {
        console.log(`Ad blocking ${isEnabled ? "enabled" : "disabled"}`);
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach((tab) => {
            if (tab.id && tab.url && !tab.url.startsWith("chrome-extension://")) {
              chrome.tabs.reload(tab.id);
            }
          });
        });
      });
    });
  }
  const cookieBannerToggle = document.getElementById("cookie-banner-toggle");
  if (cookieBannerToggle) {
    chrome.storage.local.get(["isCookieBannerBlockingOn"], (data) => {
      cookieBannerToggle.checked = data.isCookieBannerBlockingOn !== false;
    });
    cookieBannerToggle.addEventListener("change", (e) => {
      const isEnabled = e.target.checked;
      chrome.storage.local.set({ isCookieBannerBlockingOn: isEnabled }, () => {
        console.log(`Cookie banner blocking ${isEnabled ? "enabled" : "disabled"}`);
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach((tab) => {
            if (tab.id && tab.url && !tab.url.startsWith("chrome-extension://")) {
              chrome.tabs.reload(tab.id);
            }
          });
        });
      });
    });
  }
  const exportBtn = document.getElementById("export-data-btn");
  if (exportBtn) {
    exportBtn.addEventListener("click", () => {
      const dataStr = JSON.stringify(cachedData, null, 2);
      const blob = new Blob([dataStr], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `echo-logs-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    });
  }
  const clearBtn = document.getElementById("clear-cache-btn");
  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      if (confirm("Permanently delete all tracking history?")) {
        chrome.storage.local.set({
          detectedTrackers: [],
          trackersBlocked: 0,
          trackerMetadata: {}
        }, () => {
          window.location.reload();
        });
      }
    });
  }
});
