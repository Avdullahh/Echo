(function echoAdBlockerMain() {
  "use strict";
  if (window.__echoAdBlockerInjected) return;
  window.__echoAdBlockerInjected = true;
  let blockingEnabled = false;
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data?.type === "ECHO_ENABLE_BLOCKING") {
      blockingEnabled = true;
      bypassAlternateContentDetection();
      console.log("[Echo AdBlock] MAIN: Blocking enabled via message");
    }
    if (event.data?.type === "ECHO_DISABLE_BLOCKING") {
      blockingEnabled = false;
      console.log("[Echo AdBlock] MAIN: Blocking disabled via message");
    }
  });
  const GESTURE_TIMEOUT_MS = 1e3;
  let lastTrustedGestureTime = 0;
  let lastTrustedGestureTarget = null;
  const TRUSTED_EVENT_TYPES = [
    "click",
    "mousedown",
    "mouseup",
    "touchstart",
    "touchend",
    "keydown",
    "keyup",
    "keypress"
  ];
  function recordTrustedGesture(event) {
    if (event.isTrusted) {
      lastTrustedGestureTime = Date.now();
      lastTrustedGestureTarget = event.target;
    }
  }
  TRUSTED_EVENT_TYPES.forEach((type) => {
    window.addEventListener(type, recordTrustedGesture, true);
  });
  const TRUSTED_POPUP_DOMAINS = /* @__PURE__ */ new Set([
    "google.com",
    "accounts.google.com",
    "mail.google.com",
    "docs.google.com",
    "drive.google.com",
    "meet.google.com",
    "facebook.com",
    "twitter.com",
    "x.com",
    "apple.com",
    "appleid.apple.com",
    "microsoft.com",
    "login.microsoftonline.com",
    "outlook.com",
    "office.com",
    "live.com",
    "teams.microsoft.com",
    "github.com",
    "gitlab.com",
    "paypal.com",
    "checkout.paypal.com",
    "stripe.com",
    "checkout.stripe.com",
    "youtube.com",
    "vimeo.com",
    "spotify.com",
    "linkedin.com",
    "instagram.com",
    "reddit.com",
    "zoom.us",
    "whereby.com",
    "amazon.com",
    "ebay.com",
    "etsy.com",
    "wikipedia.org",
    "stackoverflow.com",
    "dropbox.com",
    "notion.so",
    "slack.com",
    "discord.com",
    "telegram.org",
    "twitch.tv",
    "netflix.com",
    "bankofamerica.com",
    "chase.com",
    "barclays.co.uk",
    "revolut.com",
    "monzo.com",
    "paypal.com"
  ]);
  const AD_POPUP_PATTERNS = [
    "doubleclick",
    "googlesyndication",
    "googleadservices",
    "popads",
    "popcash",
    "popunder",
    "pop-under",
    "adnxs",
    "adform",
    "criteo",
    "taboola",
    "outbrain",
    "adsrvr",
    "rubiconproject",
    "pubmatic",
    "openx",
    "exoclick",
    "juicyads",
    "plugrush",
    "propellerads",
    "trafficjunky",
    "trafficfactory",
    "adcash",
    "adclick",
    "yllix",
    "hilltopads",
    "bidvertiser",
    "clickadu",
    "adsterra",
    "ero-advertising",
    "zeropark",
    "mgid",
    "revcontent",
    "content.ad",
    "sharethrough",
    "adf.ly",
    "shorte.st",
    "linkbucks",
    "bc.vc",
    "/ads/",
    "/ad/",
    "adserver",
    "adclick",
    "aff=",
    "affid=",
    "affiliate",
    "popuptraffic",
    "popup-ad",
    "adpop"
  ];
  function getHostname(urlStr) {
    try {
      return new URL(urlStr).hostname.replace(/^www\./, "");
    } catch {
      return "";
    }
  }
  function isTrustedDomain(hostname) {
    for (const trusted of TRUSTED_POPUP_DOMAINS) {
      if (hostname === trusted || hostname.endsWith("." + trusted)) {
        return true;
      }
    }
    return false;
  }
  function isKnownAdUrl(urlStr) {
    const lower = urlStr.toLowerCase();
    return AD_POPUP_PATTERNS.some((p) => lower.includes(p));
  }
  function hasRecentTrustedGesture() {
    return Date.now() - lastTrustedGestureTime < GESTURE_TIMEOUT_MS;
  }
  function showPopupToast(urlStr, onAllow, onBlock) {
    document.getElementById("echo-popup-toast")?.remove();
    const hostname = getHostname(urlStr) || urlStr.substring(0, 40);
    const toast = document.createElement("div");
    toast.id = "echo-popup-toast";
    toast.style.cssText = `
      position: fixed !important;
      bottom: 24px !important;
      right: 24px !important;
      z-index: 2147483647 !important;
      background: #0f1117 !important;
      border: 1px solid rgba(77,255,188,0.25) !important;
      border-radius: 14px !important;
      padding: 14px 16px !important;
      color: #e2e8f0 !important;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
      font-size: 13px !important;
      max-width: 300px !important;
      min-width: 260px !important;
      box-shadow: 0 8px 32px rgba(0,0,0,0.5), 0 0 0 1px rgba(77,255,188,0.08) !important;
      animation: echo-toast-in 0.2s cubic-bezier(0.34,1.56,0.64,1) !important;
      pointer-events: all !important;
    `;
    toast.innerHTML = `
      <style>
        @keyframes echo-toast-in {
          from { transform: translateY(12px) scale(0.96); opacity: 0; }
          to   { transform: translateY(0) scale(1);       opacity: 1; }
        }
        #echo-popup-toast * { box-sizing: border-box !important; }
      </style>
      <div style="display:flex;align-items:flex-start;gap:10px;">
        <div style="width:32px;height:32px;border-radius:8px;background:rgba(77,255,188,0.1);border:1px solid rgba(77,255,188,0.2);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:15px;">🛡️</div>
        <div style="flex:1;min-width:0;">
          <div style="font-weight:700;color:#4dffbc;font-size:11px;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:4px;">Echo — Popup Blocked</div>
          <div style="color:#94a3b8;font-size:12px;margin-bottom:10px;line-height:1.4;">
            <strong style="color:#cbd5e1;">${hostname}</strong> wants to open a new window
          </div>
          <div style="display:flex;gap:6px;">
            <button id="echo-popup-allow" style="
              flex:1;padding:7px 10px;border-radius:8px;border:1px solid rgba(77,255,188,0.3);
              background:rgba(77,255,188,0.12);color:#4dffbc;
              font-size:12px;font-weight:600;font-family:inherit;cursor:pointer;
              transition:background 0.15s;
            " onmouseover="this.style.background='rgba(77,255,188,0.22)'" 
              onmouseout="this.style.background='rgba(77,255,188,0.12)'">
              Allow
            </button>
            <button id="echo-popup-block" style="
              flex:1;padding:7px 10px;border-radius:8px;border:1px solid rgba(239,68,68,0.25);
              background:rgba(239,68,68,0.08);color:#f87171;
              font-size:12px;font-weight:600;font-family:inherit;cursor:pointer;
              transition:background 0.15s;
            " onmouseover="this.style.background='rgba(239,68,68,0.18)'" 
              onmouseout="this.style.background='rgba(239,68,68,0.08)'">
              Block
            </button>
          </div>
          <div style="margin-top:7px;font-size:10px;color:#475569;text-align:center;">
            Auto-blocking in <span id="echo-popup-countdown">8</span>s
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(toast);
    let secondsLeft = 8;
    const countdownEl = toast.querySelector("#echo-popup-countdown");
    const countdownInterval = setInterval(() => {
      secondsLeft--;
      if (countdownEl) countdownEl.textContent = secondsLeft.toString();
    }, 1e3);
    const autoTimer = setTimeout(() => {
      clearInterval(countdownInterval);
      toast.remove();
      onBlock();
    }, 8e3);
    const cleanup = () => {
      clearTimeout(autoTimer);
      clearInterval(countdownInterval);
      toast.remove();
    };
    toast.querySelector("#echo-popup-allow").addEventListener("click", () => {
      cleanup();
      onAllow();
    });
    toast.querySelector("#echo-popup-block").addEventListener("click", () => {
      cleanup();
      onBlock();
    });
  }
  const originalWindowOpen = window.open.bind(window);
  window.open = function(url, target, features) {
    if (!blockingEnabled) {
      return originalWindowOpen(url, target, features);
    }
    const urlStr = (url || "").toString().trim();
    if (!urlStr || urlStr === "" || urlStr.toLowerCase() === "about:blank") {
      console.log("[Echo PopupBlocker] ✓ Silently blocked click hijack popup");
      return null;
    }
    if (isKnownAdUrl(urlStr)) {
      console.log("[Echo PopupBlocker] ✓ Silently blocked ad popup:", urlStr.substring(0, 80));
      return null;
    }
    const hostname = getHostname(urlStr);
    if (isTrustedDomain(hostname)) {
      console.log("[Echo PopupBlocker] ✓ Allowed trusted popup:", hostname);
      return originalWindowOpen(url, target, features);
    }
    if (hasRecentTrustedGesture()) {
      console.log("[Echo PopupBlocker] ✓ Allowed gesture-triggered popup:", hostname);
      return originalWindowOpen(url, target, features);
    }
    console.log("[Echo PopupBlocker] ⚠ Intercepted ambiguous popup:", urlStr.substring(0, 80));
    showPopupToast(
      urlStr,
      () => {
        console.log("[Echo PopupBlocker] User allowed popup:", hostname);
        originalWindowOpen(url, target, features);
      },
      () => {
        console.log("[Echo PopupBlocker] User blocked popup:", hostname);
      }
    );
    return null;
  };
  const originalSetTimeout = window.setTimeout.bind(window);
  const originalSetInterval = window.setInterval.bind(window);
  window.setTimeout = function(fn, delay, ...args) {
    const capturedGestureTime = lastTrustedGestureTime;
    return originalSetTimeout(function() {
      if (lastTrustedGestureTime === capturedGestureTime && delay && delay > 100) {
        lastTrustedGestureTime = 0;
      }
      if (typeof fn === "function") {
        fn(...args);
      } else {
        new Function(fn)();
      }
    }, delay);
  };
  window.setInterval = function(fn, delay, ...args) {
    return originalSetInterval(function() {
      if (delay && delay > 100) {
        lastTrustedGestureTime = 0;
      }
      if (typeof fn === "function") {
        fn(...args);
      }
    }, delay);
  };
  if ("Notification" in window) {
    const OriginalNotification = window.Notification;
    const FakeNotification = function(title, options) {
      if (!blockingEnabled) return new OriginalNotification(title, options);
      console.log("[Echo AdBlock] ✓ Blocked notification:", title);
    };
    FakeNotification.permission = "denied";
    FakeNotification.requestPermission = () => Promise.resolve("denied");
    FakeNotification.prototype = OriginalNotification.prototype;
    window.Notification = FakeNotification;
  }
  if ("serviceWorker" in navigator) {
    const originalRegister = navigator.serviceWorker.register.bind(navigator.serviceWorker);
    navigator.serviceWorker.register = function(scriptURL, options) {
      if (!blockingEnabled) return originalRegister(scriptURL, options);
      const urlStr = scriptURL.toString().toLowerCase();
      if (urlStr.includes("push") || urlStr.includes("notification") || urlStr.includes("onesignal")) {
        console.log("[Echo AdBlock] ✓ Blocked push service worker:", scriptURL);
        return Promise.reject(new Error("Push SW blocked by Echo"));
      }
      return originalRegister(scriptURL, options);
    };
  }
  const adblockProperties = [
    "adsbygoogle",
    "google_ad_client",
    "googletag",
    "google_ads",
    "__google_ad_urls",
    "googlefc",
    "adBlocker",
    "adblockDetector",
    "blockAdBlock",
    "fuckAdBlock",
    "sniffAdBlock",
    "canRunAds",
    "isAdBlockActive",
    "adBlockDetected",
    "adBlockEnabled",
    "hasAdblock",
    "detectAdBlock",
    "adblock_detected",
    "adblock_test"
  ];
  for (const prop of adblockProperties) {
    try {
      Object.defineProperty(window, prop, {
        get() {
          if (prop === "canRunAds") return true;
          if (prop === "adsbygoogle") return { loaded: true, push: function() {
          } };
          if (prop === "googletag") return {
            cmd: { push: function(fn) {
              try {
                fn();
              } catch (e) {
              }
            } },
            pubads: function() {
              return {
                refresh: function() {
                },
                setTargeting: function() {
                  return this;
                },
                addEventListener: function() {
                }
              };
            },
            enableServices: function() {
            },
            display: function() {
            },
            defineSlot: function() {
              return { addService: function() {
                return this;
              } };
            },
            companionAds: function() {
              return { setRefreshUnfilledSlots: function() {
              } };
            }
          };
          return void 0;
        },
        set() {
        },
        configurable: true
      });
    } catch (e) {
    }
  }
  window.ga = function() {
  };
  window.gtag = function() {
  };
  window.__ga_disable = true;
  window[`ga-disable-UA-XXXXX-Y`] = true;
  window.Sentry = {
    init: function() {
    },
    captureException: function() {
    },
    captureMessage: function() {
    },
    configureScope: function() {
    },
    withScope: function() {
    }
  };
  window.BlockAdBlock = function() {
    this.onDetected = function() {
      return this;
    };
    this.onNotDetected = function(fn) {
      if (fn) fn();
      return this;
    };
    this.check = function() {
      return this;
    };
    this.emitEvent = function() {
      return this;
    };
  };
  window.blockAdBlock = new window.BlockAdBlock();
  window.FuckAdBlock = window.BlockAdBlock;
  window.fuckAdBlock = window.blockAdBlock;
  window.detectAdBlocker = function() {
    return false;
  };
  window.checkAdBlocker = function() {
    return false;
  };
  window.isAdBlockerActive = function() {
    return false;
  };
  console.log("[Echo AdBlock] ✓ Anti-adblock bypass active");
  function removeInterstitials() {
    if (!blockingEnabled) return;
    document.querySelectorAll("div, section, aside").forEach(function(el) {
      const htmlEl = el;
      const style = getComputedStyle(htmlEl);
      const zIndex = parseInt(style.zIndex) || 0;
      const isFixed = style.position === "fixed";
      const isAbsolute = style.position === "absolute";
      if (zIndex > 999999 && (isFixed || isAbsolute)) {
        const width = htmlEl.offsetWidth;
        const height = htmlEl.offsetHeight;
        if (width > window.innerWidth * 0.7 || height > window.innerHeight * 0.7) {
          htmlEl.remove();
          console.log("[Echo AdBlock] ✓ Removed interstitial overlay");
        }
      }
    });
    const interstitialSelectors = [
      '[class*="interstitial"]',
      '[id*="interstitial"]',
      '[class*="overlay-ad"]',
      '[class*="ad-overlay"]',
      '[class*="modal-ad"]',
      '[class*="popup-ad"]',
      '[class*="fullscreen-ad"]',
      '[class*="splash-ad"]',
      '[class*="welcome-ad"]',
      '[class*="subscribe-modal"]',
      '[class*="newsletter-popup"]'
    ];
    interstitialSelectors.forEach(function(selector) {
      document.querySelectorAll(selector).forEach(function(el) {
        el.remove();
      });
    });
    if (document.body?.style.overflow === "hidden") document.body.style.overflow = "";
    if (document.documentElement.style.overflow === "hidden") document.documentElement.style.overflow = "";
  }
  function removeVideoAds() {
    if (!blockingEnabled) return;
    const videoAdSelectors = [
      ".video-ads",
      ".videoAdUi",
      '[class*="video-ad"]',
      ".ytp-ad-player-overlay",
      ".ytp-ad-action-interstitial",
      ".ytp-ad-skip-button-container",
      ".ad-showing .ytp-chrome-bottom"
    ];
    videoAdSelectors.forEach(function(selector) {
      document.querySelectorAll(selector).forEach(function(el) {
        el.style.display = "none";
      });
    });
  }
  function removeBannerAds() {
    if (!blockingEnabled) return;
    const bannerSelectors = [
      '[class*="banner-ad"]',
      '[id*="banner-ad"]',
      '[class*="leaderboard-ad"]',
      '[class*="mrec-ad"]',
      '[class*="skyscraper-ad"]',
      '[class*="halfpage-ad"]'
    ];
    bannerSelectors.forEach(function(selector) {
      document.querySelectorAll(selector).forEach(function(el) {
        el.style.display = "none";
      });
    });
  }
  function removePushAds() {
    if (!blockingEnabled) return;
    const pushSelectors = [
      "#onesignal-bell-container",
      "#onesignal-slidedown-container",
      '[class*="push-prompt"]',
      '[class*="notification-prompt"]'
    ];
    pushSelectors.forEach(function(selector) {
      document.querySelectorAll(selector).forEach(function(el) {
        el.style.display = "none";
      });
    });
  }
  document.addEventListener("click", function(e) {
    if (!blockingEnabled) return;
    const target = e.target;
    const anchor = target.closest ? target.closest("a") : null;
    if (anchor && anchor.target === "_blank") {
      const href = (anchor.href || "").toLowerCase();
      if (href.includes("ad.") || href.includes("/ads/") || href.includes("click.") || href.includes("doubleclick") || href.includes("track.") || href.includes("redirect") || href.includes("affiliate") || href.includes("aff=")) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        console.log("[Echo AdBlock] ✓ Blocked ad link click");
      }
    }
  }, true);
  function bypassAlternateContentDetection() {
    if (!blockingEnabled) return;
    const adClassPatterns = [
      "ad-widget",
      "adbox",
      "adsbox",
      "ad-container",
      "advertisement",
      "adsbygoogle",
      "banner_ads",
      "ad-placeholder",
      "ad-slot",
      "ad-unit"
    ];
    const observer2 = new MutationObserver(() => {
      adClassPatterns.forEach((pattern) => {
        document.querySelectorAll(`[class*="${pattern}"]`).forEach((el) => {
          const htmlEl = el;
          if (getComputedStyle(htmlEl).display === "none") {
            Object.defineProperty(htmlEl, "offsetHeight", {
              get: () => 1,
              configurable: true
            });
            Object.defineProperty(htmlEl, "offsetWidth", {
              get: () => 1,
              configurable: true
            });
          }
        });
      });
    });
    if (document.body) {
      observer2.observe(document.body, { childList: true, subtree: true });
    } else {
      document.addEventListener("DOMContentLoaded", () => {
        observer2.observe(document.body, { childList: true, subtree: true });
      });
    }
  }
  function runBlockers() {
    if (!blockingEnabled) return;
    removeInterstitials();
    removeVideoAds();
    removeBannerAds();
    removePushAds();
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", runBlockers);
  } else {
    runBlockers();
  }
  const observer = new MutationObserver(function(mutations) {
    if (!blockingEnabled) return;
    let shouldCheck = false;
    for (const mutation of mutations) {
      if (mutation.addedNodes.length > 0) {
        shouldCheck = true;
        break;
      }
    }
    if (shouldCheck) runBlockers();
  });
  function startObserver() {
    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true });
    } else {
      setTimeout(startObserver, 10);
    }
  }
  startObserver();
  setInterval(runBlockers, 1500);
  console.log("[Echo AdBlock] ✓ MAIN world script ready — awaiting enable signal");
})();
